# Carmezin Store — Binance Pay

Versão da loja configurada para aceitar **somente Binance Pay**.

## O que funciona
- Catálogo, busca e categorias
- Carrinho
- Criação de pedido no servidor
- SQLite e estoque de keys
- Checkout Binance Pay
- Valor convertido de BRL para BTC pela cotação pública da Binance no momento da compra
- Consulta do pedido e confirmação automática pelo status do pedido Binance Pay
- Entrega automática da key após status `PAID`

A integração usa a API oficial do Binance Pay. As requisições são assinadas com HMAC-SHA512 e devem ficar no servidor. Para produção, a Binance exige HTTPS para as chamadas da integração. Consulte a documentação oficial antes de publicar. 

## Configuração
1. Instale Node.js 20+.
2. Copie `.env.example` para `.env`.
3. Crie uma conta Merchant no Binance Pay e gere o Certificate SN/API identity key e Secret Key.
4. Preencha `BINANCE_PAY_CERTIFICATE_SN` e `BINANCE_PAY_SECRET_KEY`.
5. Configure `BASE_URL` com o domínio HTTPS público da loja.
6. Rode `npm install`.
7. Rode `npm start`.
8. Abra a loja.

**Nunca coloque a Secret Key no HTML, JavaScript do navegador ou GitHub.**

## Cadastrar keys
POST `/api/admin/keys`
Header: `x-admin-key: SUA_ADMIN_KEY`
JSON:
`{"productId":1,"key":"SUA-KEY-AQUI"}`

## Pagamento
O checkout cria um pedido Binance Pay em BTC. A loja consulta o status do pedido na API oficial e só libera a key quando o Binance Pay retornar `PAID`.

> Observação: o cálculo BRL → BTC usa a cotação disponível na Binance no instante da criação do pedido. Em produção, use domínio HTTPS e configure corretamente a conta Merchant/API no Binance Pay.
