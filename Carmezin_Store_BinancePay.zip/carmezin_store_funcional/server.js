import express from "express";
import dotenv from "dotenv";
import Database from "better-sqlite3";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app=express(), port=Number(process.env.PORT||3000);
const __filename=fileURLToPath(import.meta.url), __dirname=path.dirname(__filename);
const db=new Database(path.join(__dirname,"store.db"));
db.pragma("journal_mode=WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT, game TEXT NOT NULL, name TEXT NOT NULL,
 price_cents INTEGER NOT NULL, slug TEXT UNIQUE, active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS keys_stock(
 id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, key_value TEXT NOT NULL UNIQUE,
 sold INTEGER DEFAULT 0, order_id INTEGER, FOREIGN KEY(product_id) REFERENCES products(id)
);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, status TEXT NOT NULL,
 total_cents INTEGER NOT NULL, binance_trade_no TEXT, binance_prepay_id TEXT, binance_payment_id TEXT, payment_amount TEXT, payment_currency TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
 qty INTEGER NOT NULL, unit_price_cents INTEGER NOT NULL, delivered_key TEXT,
 FOREIGN KEY(order_id) REFERENCES orders(id), FOREIGN KEY(product_id) REFERENCES products(id)
)`);

// Migração simples para instalações que já possuíam a versão anterior.
for (const stmt of [
  "ALTER TABLE orders ADD COLUMN binance_trade_no TEXT",
  "ALTER TABLE orders ADD COLUMN binance_prepay_id TEXT",
  "ALTER TABLE orders ADD COLUMN binance_payment_id TEXT",
  "ALTER TABLE orders ADD COLUMN payment_amount TEXT",
  "ALTER TABLE orders ADD COLUMN payment_currency TEXT"
]) { try { db.exec(stmt); } catch (_) {} }

const seed=[
["Rust","Rust Key Básica",2990,"rust-key-basica"],
["Rust","Rust Key Premium",4990,"rust-key-premium"],
["CS2","CS2 Key Básica",2490,"cs2-key-basica"],
["CS2","CS2 Key Premium",3990,"cs2-key-premium"],
["Squad","Squad Key Básica",3490,"squad-key-basica"],
["Squad","Squad Key Premium",5490,"squad-key-premium"],
["FiveM","FiveM Key Básica",1990,"fivem-key-basica"],
["FiveM","FiveM Key Premium",3490,"fivem-key-premium"]
];
const insert=db.prepare("INSERT OR IGNORE INTO products(game,name,price_cents,slug) VALUES(?,?,?,?)");
for(const p of seed) insert.run(...p);

app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));

function products(){
 return db.prepare(`SELECT p.*, (SELECT COUNT(*) FROM keys_stock k WHERE k.product_id=p.id AND k.sold=0) stock FROM products p WHERE active=1 ORDER BY id`).all();
}
app.get("/api/products",(req,res)=>res.json(products()));

function binanceHeaders(body) {
  const timestamp = Date.now().toString();
  const nonce = crypto.randomBytes(16).toString("hex");
  const payload = `${timestamp}\n${nonce}\n${body}\n`;
  const signature = crypto.createHmac("sha512", process.env.BINANCE_PAY_SECRET_KEY).update(payload).digest("hex").toUpperCase();
  return {
    "Content-Type":"application/json",
    "BinancePay-Timestamp":timestamp,
    "BinancePay-Nonce":nonce,
    "BinancePay-Certificate-SN":process.env.BINANCE_PAY_CERTIFICATE_SN,
    "BinancePay-Signature":signature
  };
}

async function binancePay(pathname, payload) {
  const body = JSON.stringify(payload);
  const r = await fetch(`https://bpay.binanceapi.com${pathname}`, {method:"POST", headers:binanceHeaders(body), body});
  const data = await r.json();
  if(!r.ok || data.status !== "SUCCESS") throw new Error(data.errorMessage || `Binance Pay error ${data.code || r.status}`);
  return data;
}

async function btcBrlRate() {
  const direct = await fetch("https://api.binance.com/api/v3/ticker/price?symbol=BTCBRL");
  if(direct.ok) {
    const d=await direct.json();
    if(d.price) return Number(d.price);
  }
  const [btc, usdt] = await Promise.all([
    fetch("https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT").then(r=>r.json()),
    fetch("https://api.binance.com/api/v3/ticker/price?symbol=USDTBRL").then(r=>r.json())
  ]);
  if(!btc.price || !usdt.price) throw new Error("Não foi possível obter a cotação BTC/BRL");
  return Number(btc.price)*Number(usdt.price);
}

app.post("/api/orders", async (req,res)=>{
 try{
  if(!process.env.BINANCE_PAY_CERTIFICATE_SN || !process.env.BINANCE_PAY_SECRET_KEY) {
    return res.status(503).json({error:"Binance Pay ainda não está configurado no servidor."});
  }
  const items=Array.isArray(req.body.items)?req.body.items:[];
  if(!items.length) return res.status(400).json({error:"Carrinho vazio"});
  const ids=items.map(x=>Number(x.productId)).filter(Boolean);
  const rows=db.prepare(`SELECT * FROM products WHERE active=1 AND id IN (${ids.map(()=>"?").join(",")})`).all(...ids);
  let total=0, normalized=[];
  for(const x of items){
   const p=rows.find(r=>r.id===Number(x.productId)); const qty=Math.max(1,Math.min(10,Number(x.qty||1)));
   if(!p) return res.status(400).json({error:"Produto inválido"});
   const stock=db.prepare("SELECT COUNT(*) c FROM keys_stock WHERE product_id=? AND sold=0").get(p.id).c;
   if(stock<qty) return res.status(409).json({error:`Sem estoque suficiente para ${p.name}`});
   total+=p.price_cents*qty; normalized.push({p,qty});
  }
  const code="CMZ"+crypto.randomBytes(5).toString("hex").toUpperCase();
  const order=db.prepare("INSERT INTO orders(code,status,total_cents,payment_currency) VALUES(?,?,?,?)").run(code,"pending",total,"BTC");
  const orderId=order.lastInsertRowid;
  const addItem=db.prepare("INSERT INTO order_items(order_id,product_id,qty,unit_price_cents) VALUES(?,?,?,?)");
  for(const x of normalized) addItem.run(orderId,x.p.id,x.qty,x.p.price_cents);

  const rate=await btcBrlRate();
  const btcAmount=Number((total/100/rate).toFixed(8));
  if(!btcAmount || btcAmount<=0) throw new Error("Valor BTC inválido");
  const base=process.env.BASE_URL||`http://localhost:${port}`;
  const payload={
    merchantTradeNo:code,
    orderAmount:btcAmount,
    currency:"BTC",
    description:"Compra na Carmezin Store",
    goodsDetails:normalized.map(x=>({goodsType:"01",goodsCategory:"D000",referenceGoodsId:String(x.p.id),goodsName:x.p.name,goodsDetail:`${x.qty} unidade(s)`})),
    returnUrl:`${base}/pedido.html?code=${code}`,
    cancelUrl:`${base}/pedido.html?code=${code}`,
    goods:{goodsType:"01",goodsCategory:"D000",referenceGoodsId:code,goodsName:"Carmezin Store",goodsDetail:"Keys digitais"}
  };
  const response=await binancePay("/binancepay/openapi/order",payload);
  const d=response.data||{};
  db.prepare("UPDATE orders SET binance_trade_no=?,binance_prepay_id=?,payment_amount=?,payment_currency=? WHERE id=?")
    .run(code,d.prepayId||null,String(btcAmount),"BTC",orderId);
  res.status(201).json({orderCode:code,checkoutUrl:d.checkoutUrl||d.universalUrl||d.qrcodeLink||null,paymentAmount:btcAmount,currency:"BTC"});
 }catch(e){console.error(e);res.status(500).json({error:e.message||"Não foi possível criar o pedido Binance Pay"});}
});

async function syncBinanceOrder(order){
 if(order.status==="paid") return;
 if(!order.binance_trade_no || !process.env.BINANCE_PAY_CERTIFICATE_SN || !process.env.BINANCE_PAY_SECRET_KEY) return;
 try {
  const response=await binancePay("/binancepay/openapi/order/query",{merchantTradeNo:order.binance_trade_no});
  const d=response.data;
  if(!d) return;
  if(d.status==="PAID"){
   db.prepare("UPDATE orders SET binance_payment_id=?,status='paid' WHERE id=?").run(d.transactionId||null,order.id);
   const fresh=db.prepare("SELECT * FROM orders WHERE id=?").get(order.id);
   fulfill(fresh);
  } else if(["CANCELED","ERROR","EXPIRED","REFUNDED"].includes(d.status)) {
   db.prepare("UPDATE orders SET status=? WHERE id=?").run(d.status.toLowerCase(),order.id);
  }
 } catch(e) { console.error("Binance Pay query:",e.message); }
}

app.get("/api/orders/:code",async (req,res)=>{
 let order=db.prepare("SELECT * FROM orders WHERE code=?").get(req.params.code);
 if(order) await syncBinanceOrder(order);
 order=db.prepare("SELECT * FROM orders WHERE code=?").get(req.params.code);
 if(!order) return res.status(404).json({error:"Pedido não encontrado"});
 const items=db.prepare(`SELECT oi.*,p.name,p.game FROM order_items oi JOIN products p ON p.id=oi.product_id WHERE oi.order_id=?`).all(order.id);
 res.json({...order,items:items.map(x=>({name:x.name,game:x.game,qty:x.qty,key:x.delivered_key||null}))});
});

app.post("/api/admin/keys",(req,res)=>{
 if(req.headers["x-admin-key"]!==process.env.ADMIN_KEY) return res.status(401).json({error:"Não autorizado"});
 const {productId,key}=req.body||{};
 if(!productId||!key) return res.status(400).json({error:"productId e key são obrigatórios"});
 try{db.prepare("INSERT INTO keys_stock(product_id,key_value) VALUES(?,?)").run(Number(productId),String(key));res.json({ok:true})}
 catch(e){res.status(400).json({error:"Key duplicada ou inválida"})}
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(port,()=>console.log(`Carmezin Store: http://localhost:${port}`));
